import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { deleteGoal } from "../features/goals/goalSlice";

function GoalItem({ goal }) {
  const dispatch = useDispatch();
  const [base64, setBase64] = useState("");

  useEffect(() => {
    const a = new Uint8Array(goal.img.data.data);
    const b = a.reduce((data, byte) => {
      return data + String.fromCharCode(byte);
    }, "");
    setBase64(btoa(b));
  }, [goal]);

  return (
    <div className="goal">
      <div>{new Date(goal.createdAt).toLocaleString("en-US")}</div>
      <h2
        style={{
          backgroundColor: "black",
          padding: "10px",
          marginTop: "10px",
          color: "white",
        }}
      >
        {goal.text}
      </h2>
      <br />
      <h5 style={{ color: "#555" }}>
        {goal.discription} - {goal.category}
      </h5>
      <br />
      <img
        alt=""
        width={"80%"}
        style={{ borderRadius: "20px" }}
        src={"data:" + goal.img.contentType + ";base64," + base64}
      />
      <h4 className="">
        Rs. {goal.currentPrice}/{goal.price}
      </h4>
      <button onClick={() => dispatch(deleteGoal(goal._id))} className="close">
        X
      </button>
    </div>
  );
}

export default GoalItem;
