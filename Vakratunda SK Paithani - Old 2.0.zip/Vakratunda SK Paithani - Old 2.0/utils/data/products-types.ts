export const productsTypes = [
  {
    id: "0",
    name: "All Paithani",
    value: "all-paithani",
  },
  {
    id: "1",
    name: "Semi Silk Paithani",
    value: "semi-silk-paithani",
  },
  {
    id: "2",
    name: "Pure Silk Paithani",
    value: "pure-silk-paithani",
  },
];

export default productsTypes;
