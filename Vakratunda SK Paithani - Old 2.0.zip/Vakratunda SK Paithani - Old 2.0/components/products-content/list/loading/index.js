import ProductItemLoading from './../../../product-item/loading';

const ProductsLoading = () => {
  return (
    <section className="products-list">
      <ProductItemLoading />
      <ProductItemLoading />
      <ProductItemLoading />
      <ProductItemLoading />
      <ProductItemLoading />
      <ProductItemLoading />
    </section>
  );
};
  
export default ProductsLoading